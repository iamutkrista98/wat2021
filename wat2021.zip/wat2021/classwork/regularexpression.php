<?php     
/*$password="hello123";
$pattern = "/^(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9])\S{6,}$/";
if(preg_match($pattern,$password)){
    echo "Password Strength Match";
}
else{
    echo "Password Strength Not Match";
}*/


$email = 'utkrista.acharya@yahoo.com';
$pattern="/^([a-z0-9\+_\-]+)(\.[a-z0-9\+_\-]+)*@([a-z0-9\-]+\.)+[a-z]{2,6}$/ix";
if(preg_match($pattern,$email)){
    echo("Email Valid");
}
else{
    echo("Email Invalid");
}
?>