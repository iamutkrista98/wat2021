<?php
//for loop
//while loop
//do while loop
//for each loop

for($i=1;$i<=10;$i++)
{
    echo $i."<br>";
}

//display the numbers into the table cell
echo "<table border =1>";
for($i=1;$i<=10;$i++)
{
    echo "<tr><td> $i</td></tr>";
}

echo"</table>";


?>