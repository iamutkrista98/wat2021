<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <div>Banner</div>
    <div>
        <nav>
            <li><a href="index.php">Home</a></li>
            <?php
            $sql="SELECT * FROM category WHERE status=1 ORDER BY category_id ASC";
            include('db/connection.php');
            $qry = mysqli_query($conn,$sql);
            while($row=mysqli_fetch_array($qry))
            {
                echo "<li><a href=category.php?id=".$row['category_id'].'>'.$row['category_name']."</a>.'</li>";
            }
            
            
            
            
            ?>

        </nav>
    </div>
    <div>Details</div>
    <div>Footer</div>
</body>
</html>