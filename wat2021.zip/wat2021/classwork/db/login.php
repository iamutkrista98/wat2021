<?php         
session_start();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    if(isset($_GET['msg'])) {
        echo "<h2>".$_GET['msg']."</h2>";
    }      
    ?>
    <?php
        if(isset($_POST['login']))
        {
            $username = $_POST['uname'];
            $temp = $_POST['upass'];
            $upassword = md5($_POST['upass']);
            $rememberme = $_POST['rememberme'];
            if($rememberme==1) {
                setcookie('username',$username,time()+60*60*24*7,'/');
                setcookie('password',$temp,time()+60*60*24*7,'/');

            }

            $sql = "SELECT * FROM users WHERE username = '$username' AND password = '$upassword' AND status = 1";
            include('connection.php');
            $qry = mysqli_query($conn,$sql) or die(mysqli_error($conn));
            $count = mysqli_num_rows($qry);
            if($count==1)
            {
                //creating session 
                $_SESSION['username'] = $username;
                $_SESSION['uniquevalue'] = date('-m-d-h:m:s');
                header("Location:dashboard.php?");
            }
            else
            {
                header("Location: login.php?msg=Unable to Login");
            }
            
        
        }


    ?>
<form method='post' action='' name='userlogin'>
<fieldset>
<legend>User Login</legend>
<label>Username</label>
<input type='text' name='uname' placeholder='username' value='<?php if(isset($_COOKIE['username'])){echo $_COOKIE['username'];} ?>'><br>       
<label>Password</label>
<input type='password' name='upass' placeholder='password' value='<?php if(isset($_COOKIE['password'])){echo $_COOKIE['password'];} ?>'><br>   
<input type='checkbox' name='rememberme' value='1'>Remember Me<br>
<input type='submit' name='login'><br>   
<span>Dont have an account?</span>
<a href='userregister.php'>SignUp</a>    
</fieldset>

</form>
    
</body>
</html>