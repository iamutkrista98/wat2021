<?php   
session_start();
if(!isset($_SESSION['username']) && !isset($_SESSION['uniquevalue']))
{
    header("Location: login.php");

}

?>           

