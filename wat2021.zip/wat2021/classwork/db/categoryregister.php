<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Category Registration</title>
</head>
<body>
    <?php

        if(isset($_POST['submitcat']))
        {
            $catname = $_POST['catname'];
            $filename = $_FILES['thumb']['name'];
            $filetype = $_FILES['thumb']['type'];
            $filesize = $_FILES['thumb']['size'];
            $filetempname = $_FILES['thumb']['tmp_name'];
            $catdesc = $_POST['catdesc'];
            $catstat = $_POST['catstat']; 
            $uploadlocation="uploads/".$filename;

            //uploading an image into uploads folder
            if($filetype == 'image/jpeg' || $filetype == 'image/jpg'|| $filetype=='image/gif' || $filetype == 'image/png')
            {   
                if(move_uploaded_file($filetempname,$uploadlocation))
                {  
                         //sql query
                $sql = "INSERT INTO category(name,thumb,description,status) VALUES('$catname','$filename','$catdesc','$catstat')";
                //making a connection to database
                include('connection.php');
                //execution of sql query
                $qry=mysqli_query($conn,$sql) or die(mysqli_error($conn));
                if($qry)
                {
                    header("Location: categorydisplay.php?msg=Category Inserted Successfully");
                }
                else
                {
                    echo "Could Not Be Inserted";
                }
                }
                else{
                    echo "Upload File Error";
                }
               

            }
            else {
                echo "Upload file in jpg/jpeg/gif/png file format";
            }
    


        }
    
    
    
    
    
    
    ?>
    
    <form method="POST" action="" enctype="multipart/form-data" name="registercat">
        <fieldset>
            <legend>Register Category</legend>
            <label>Category Name:</label> 
            <input type="text" name="catname" value=""><br><br>
            <label>Thumbnail:</label> 
            <input type="file" name="thumb" value=""><br><br>
            <label>Category Description:</label> 
            <textarea name="catdesc" value="" rols="5" cols="40"></textarea><br><br>
            <label>Category Status:</label> 
            <input type="text" name="catstat" value=""><br><br>
            <input type="submit" name="submitcat" value="submit">  <input type="reset" name="resetcat" value="reset">








        </fieldset>








    </form>
    
</body>
</html>