<select name="category_id" size="1">
    <?php 
        $sql = "SELECT * FROM category WHERE status=1";
        include('connection.php');
        $qry=mysqli_query($conn,$sql) or die(mysqli_error($conn));
        while($row=mysqli_fetch_array($qry))
        {
            echo "<option value=".$row['id'].">".$row['name']."</option>";
        }




?>
</select>