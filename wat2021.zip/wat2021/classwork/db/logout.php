<?php                   
include('session.php');

//clear  all sessions 
session_destroy();
header("Location: login.php?msg=logout successfully");
?>