<?php
include ('showErrors.php');
include ('wk6Select.php');

if (isset($_POST['subEvent'])) {
    $name = $_POST['txtName'];
    $pass = $_POST['txtCategory'];

    $query = "INSERT INTO events (eventName, eventCategory) VALUES ('$name', '$pass')";
    mysqli_query($connection, $query);

    header("Location: wk6Recap.php");
}
