<?php
include "showErrors.php";

$host = "localhost";
$dbname = "l52021aa";
$dbuser = "root";
$dbpass="";

// create connection

$connection = mysqli_connect($host,$dbuser,$dbpass,$dbname);

$query = "SELECT * FROM events WHERE eventCategory = 'workshop'";

$result = mysqli_query($connection, $query);

while ($row = mysqli_fetch_assoc($result)) {
    echo $row['eventName'] . " " . $row['eventCategory'] . "<br />";
}
