<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Result</title>
</head>

<body>
    <?php
    include ('showErrors.php');
    ?>
    <h1>Insert a record</h1>
    <form action="Wk6Insert.php" method="POST">
        <input type="text" name="txtName" />
        <br />
        <input type="text" name="txtCategory" />
        <br />
        <input type="submit" name="subEvent" value="Submit" />
    </form>
    <?php
    // display results
    include ('wk6select.php');
    ?>
</body>

</html>