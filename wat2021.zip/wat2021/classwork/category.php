<?php
if(isset($_GET['id'])){
    $catid  = trim($_GET['id']);
    $sql = "SELECT * FROM post WHERE id=$catid ORDER BY id DESC;
    include('db/connection.php');
    $qry = mysqli_query($conn,$sql);

    while($row = mysqli_fetch_array($qry){
    echo "<div><h3><a href='details.php?id='.$row['postid'].'>'.$row['title'].'</a></h3><img src='uploads/$row['image'].'>'.$row['shortstory'].</div>"";
}

else
{
    header('Location:index.php');
}
?>