<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sessions</title>
</head>
<body>
    <?php 
    if(isset($_GET['msg']))
    {
        echo $_GET['msg'];
    }  
   
    
    ?>     
<?php
//include init.php so session vars can be used
include ('init.php');
//Use an if statement to determine whether the session var holding
if(isset($_SESSION['username']))
{
    echo "Welcome " . $_SESSION['username'];
    echo "</br>";
    echo "<a href='protected.php'>Protected</a><br><br>";
    echo "<a href='logout.php'>Logout</a>";
} 
else           
{
    include('loginform.php');
    
    
}
//the user name ($_SESSION['user'] has been set. If it has, echo out 
//a welcome message for the user, followed by a links to a pages
//called protected.php and logout.php.
//add an else section that will include loginform.php and display any 
//error message that is held in ($_SESSION['error']
?>

    
</body>
</html>