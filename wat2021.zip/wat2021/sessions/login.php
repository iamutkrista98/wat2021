<?php
//include init.php
include('init.php');
//Gather details submitted from the $_POST array and store in local vars
if(isset($_POST['subLogin']))
{
    $username = $_POST['txtUser'];
    $password = md5($_POST['txtPass']);

//build query to SELECT records from the users table WHERE
$sql = "SELECT * FROM users WHERE username='$username' AND password='$password'";
include('connection.php');
//the username AND password in the table are equal to those entered.
//run query and store result
$result = mysqli_query($conn,$sql);
//check result and generate message with code below
if ($row = mysqli_fetch_assoc($result)) {
$_SESSION['username']=$username;
header("Location:sessions.php");
} else {
$_SESSION['error'] = 'User Not Recognised';
header("Location:sessions.php?msg=User Not Recognised");

}
mysqli_close($conn);
} 
?>