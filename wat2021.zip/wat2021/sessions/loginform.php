<?php             
echo"<h3>Login</h3>
<form method='post' action='./login.php'>
<input type='text' name='txtUser' value=''/>
<input type='password' name='txtPass' />
<input type='submit' name='subLogin' value='submit'/>
</form>";

?>