<!DOCTYPE html>
<html lang="en">
 <head>
 <title>Web Applications and Technologies</title>
 <link type="text/css" rel="stylesheet" href="main.css" />
 </head>
 <body>
 <header>
 <h1>Utkrista Acharya C7261056</h1> 
 </header>
 
 <section id="container">
 <h1>Fundamentals of PHP</h1>
 <?php
 echo '<h2><b>Selection</b></h2>';
 $day = date('l');
 echo 'it\'s '.$day.'<br/>';
 if($day=='Wednesday')
 {
     echo 'It\'s midweek';
 }
 else{
     echo 'It\'s not midweek';
 }
 echo '<br/>';
 $currhr = date('g');
 if($currhr<12){
     echo 'Good Morning';
 }
 else if($currhr>12 && $currhr<=18){
     echo 'Good Afternoon';
 }
 else {
     echo 'Good Evening';
 }
 echo '<br/>';

 $password = 'password';
 if(strlen($password)>4 && strlen($password)<10){
     echo 'Password length is not valid';
 }
 else{
     echo 'Password length is valid';
 }
 echo '<br/>';
 if($password =='password' || $password=='username'){
     echo 'Password Invalid';
 }
 else {
     echo 'Password valid';
 }

 echo '<br/>';
 echo '<br/>';
 $ticketPrice = 25;
    $age = 15;
    $membership = TRUE;
    $finalTicketPrice = 0;

    if ($age <= 12 && $membership == TRUE) {
      $finalTicketPrice = $ticketPrice - ($ticketPrice * 0.5);
      echo "Initial Ticket Price: " . $ticketPrice . "<br />";
      echo "Age: " . $age . "<br />";
      echo "Membership: " . $membership . "<br />";
      echo "Final Ticket Price: " . $finalTicketPrice . "<br />";
    } elseif ($age <= 18 && $membership == TRUE) {
      $finalTicketPrice = $ticketPrice - ($ticketPrice * 0.25);
      echo "Initial Ticket Price: " . $ticketPrice . "<br />";
      echo "Age: " . $age . "<br />";
      echo "Membership: " . $membership . "<br />";
      echo "Final Ticket Price: " . $finalTicketPrice . "<br />";
    } elseif ($age >= 65 && $membership == TRUE) {
      $finalTicketPrice = $ticketPrice - ($ticketPrice * 0.25);
      echo "Initial Ticket Price: " . $ticketPrice . "<br />";
      echo "Age: " . $age . "<br />";
      echo "Membership: " . $membership . "<br />";
      echo "Final Ticket Price: " . $finalTicketPrice . "<br />";
    } elseif ($membership == TRUE) {
      $finalTicketPrice = $ticketPrice - ($ticketPrice * 0.10);
      echo "Initial Ticket Price: " . $ticketPrice . "<br />";
      echo "Age: " . $age . "<br />";
      echo "Membership: " . $membership . "<br />";
      echo "Final Ticket Price: " . $finalTicketPrice . "<br />";
    } else {
      $finalTicketPrice = $ticketPrice;
      echo "Initial Ticket Price: " . $ticketPrice . "<br />";
      echo "Age: " . $age . "<br />";
      echo "Membership: " . $membership . "<br />";
      echo "Final Ticket Price: " . $finalTicketPrice . "<br />";
    }


 echo '<h2><b>Arrays</b></h2>';
 echo '<h3><b>Simple Arrays</b></h3>';
 $products = array('tshirt','cap','mug');
 print_r($products);
 echo '<br/>';
 $products[1] = 'shirt';
 print_r($products);
 echo '<br/>';
array_push($products,'skirt');
print_r($products);
echo '<br/>';
echo 'The item at index[2] is: '.$products[2];
echo '<br/>';
echo 'The item at index[3] is: '.$products[3];
echo '<br/>';
echo '<h3><b>Associative Arrays</b></h3>';
$customer = array("CustID"=>"12","CustName"=>"Sarah","CustAge"=>"23","CustGender"=>"F");
print_r($customer);
echo '<br/>';
$customer['CustAge'] = "32";
$customer['CustEmail'] = "sarah@gmail.com";
print_r($customer);
echo '<br/>';
echo 'Items in my customer array'.'<br/>';
echo 'The item at index[CustName] is: '.$customer['CustName'].'<br/>';
echo 'The item at index[CustEmail] is: '.$customer['CustEmail'];
echo '<br/>';
echo "<h3>Multi-Dimensional Arrays</h3>" . "<br />";
    $stock = array(
      array("t-Shirt", 9.99, 100, "blue", "green", "red"),
      array("cap", 4.99, 50, "blue", "black", "grey"),
      array("mug", 6.99, 30, "yellow", "green", "pink"),
    );

    echo "This is my order:" . "<br />";
    echo $stock[0][4] . " " . $stock[0][0] . "<br />";
    echo "Price: &pound" . $stock[0][1] . "<br />";
    echo $stock[1][5] . " " . $stock[1][0] . "<br />";
    echo "Price: &pound" . $stock[1][1] . "<br />";





echo '<h2><b>Loops</b></h2>';
echo '<h3><b>While Loop</b></h3>';
$counter = 1;
while($counter<6){
    echo 'count = '.$counter.'<br/>';
    $counter++;
}
echo '<br/>';
$shirtPrice = 9.99;
$counter = 1;
while($counter<=10){
    $total = $counter*$shirtPrice;
    echo $counter.' - £'.$total.'<br/>';
    $counter=$counter+1;
}

echo '<br/>';
echo '<table border=1px>';
$shirtPrice = 9.99;
$counter = 1;
echo '<th>Quantity</th><th>Price</th>';
while($counter<=10){
    $total = $counter*$shirtPrice;
    echo '<tr><td>'.$counter.'</td><td>£'.number_format($total,2).'</td></tr>';
    $counter=$counter+1;
}
echo '</table>';

echo '<br/>';
echo '<h3><b>For Loops</b></h3>';
$names = array("Ram","Shyam","Hari","Ganesh","Sita");
for($i=0;$i<5;$i++){
    echo $names[$i] .'<br/>';
}
echo '<br/>';
echo '<h3><b>Foreach Loops</b></h3>';
$names = array("Ram"=>"77261056","Shyam"=>"77261057","Hari"=>"77261058","Ganesh"=>"77261059","Sita"=>"77261060");
foreach($names as $k=>$v){
    echo 'Name: '.$k.' ID: '.$v.'<br/>';
}

echo '<br/>';
$city=array('Peter'=>'LEEDS','Kat'=>'bradford','Laura'=>'wakeFIeld');
print_r($city);
echo '<br/>';
foreach ( $city as $key => $value)
{
  $city[$key] = ucfirst ( strtolower ( $value));
  echo $city[$key]."<br/>";
}
print_r ( $city);













?>
 </section>
 <footer> 
 <small> <a href="../watIndex.html">Home</a></small>
 </footer>
 </body>
</html>