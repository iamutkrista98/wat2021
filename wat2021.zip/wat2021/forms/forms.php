<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forms</title>
</head>
<body>
<h1>Processing Input from HTML Forms</h1>
<h2>Login Form using POST</h2>
<form method="POST" action="forms.php">
<fieldset>
<legend>
Login
</legend>
<label for="email">Email: </label>
<input type="text" name="txtEmail"/><br /></br>
<label for="passwd">Password: </label>
<input type="password" name="txtPass" /><br /></br>
<input type="submit" value="Submit" name="loginSubmit" />
<input type="reset" value="Clear" />
</fieldset>
</form>
<?php 
if(isset($_POST['loginSubmit']))
{
    $email = $_POST['txtEmail'];
    $password = $_POST['txtPass'];
    echo "Email: $email Password: $password";
    
}


?>
<br>
<br>
<form method="POST" action="forms.php">
<fieldset>
<legend>Comments</legend>
<label for="">Email: </label>
<input type="text" name="email2" value="" /><br /><br>
<textarea rows="4" cols="50" name="comments"></textarea><br /><br>
<label for="">Click to Confirm: </label>
<input type="checkbox" name="chkConfirm" value="agree"><br /><br>
<input type="submit" value="Submit" name="submit2"/>
<input type="reset" value="Clear" />
</fieldset>
</form>
<?php 
if(isset($_POST['submit2']))
{
    $email2 = $_POST['email2'];
    $comments = $_POST['comments'];
    if (isset($_POST['chkConfirm'])){
        $confirm='Agreed';
        }
        else{
            $confirm='Not Agreed';
        }
        echo "Email: $email2";
        echo "<br>Comments: $comments";
        echo "<br>Confirm: $confirm";
    echo '<br><br>';

}


if(isset($_POST['submit2'])){

if(!empty($_POST['email2'])){
//collect data and output to screen as before
$email3 = $_POST['email2'];
$comments = $_POST['comments'];
if (isset($_POST['chkConfirm'])){
    $confirm='Agreed';
    }
    else{
        $confirm='Not Agreed';
    }
echo "Email: $email3";
echo "<br>Comments: $comments";
echo "<br>Confirm: $confirm";
}
else{
echo 'email must not be empty';
}
}



  
echo '<br>';
echo '<br>';
?>
<input type="text" name="txtEmail" value="<?php


if(isset($_POST['txtEmail'])){
echo $_POST['txtEmail'];
}
?>" /><br />
<?php
//initialization
$taxrate='';
$aftertax='';
$taxbefore='';
if(isset($_GET['submitbtn']))
{
    $taxrate = $_GET['taxrate'];
    $aftertax = $_GET['aftertax'];

}
echo"<form method='GET' name='pizza'>
<h2><b>Tax Calculator</b></h2>
<fieldset>
<legend>Without TAX calculator</legend>
After Tax Price: <input type='textbox' name='aftertax' value='$aftertax'/> Tax Rate: <input type='textbox'name='taxrate' value='$taxrate'/> <input type='submit' name='submitbtn' value='submit'/>  <input type='reset' name='clearbtn' value='clear'/> 

</fieldset>
</form>";
?>
<?php

if(isset($_GET['submitbtn']))
{
    $taxrate = $_GET['taxrate'];
    $aftertax = $_GET['aftertax'];
    $pattern="/^\d+(:?[.]\d{2})$/";
    if(empty($taxrate) || empty($aftertax))
    {
        echo"All Fields Required";
    }
    else{
        if(preg_match($pattern,$taxrate))
        {
            echo "Enter tax rate in whole number";
        }
        else{
            if(preg_match($pattern,$aftertax))
        {
            $taxbefore = (100*$aftertax)/(100+$taxrate);
            echo"<h2><b>Price Before Tax = &pound".round($taxbefore,2)."</b></h2>";
        }
    else{
        echo "Enter price with 2 decimal places";
    }

        }

    }
    
}
?>
<h1>Passing Data Appended to an URL</h1>
<h2>Pick a category</h2>
<a href="forms.php?cat=Films">Films</a>
<a href=" forms.php?cat=Books">Books</a>
<a href=" forms.php?cat=Music">Music</a>
<?php
if(isset($_GET['cat']))
{
    echo "<br><h2><b>The category chosen is ".$_GET['cat']."</b></h2>";
}
?>

</body>
</html>