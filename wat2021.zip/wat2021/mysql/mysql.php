<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MySQL</title>
</head>
<body>
    <form method="POST" action="insertRecord.php">
        <fieldset>
            <legend>Enter Customer Details</legend>
            <label>First Name: </label><input type="text" name="fname" value=""/><br><br>
            <label>Surname: </label><input type="text" name="lname" value=""/><br><br>
            <label>Email: </label><input type="email" name="email" value=""/><br><br>
            <label>Password: </label><input type="password" name="password" value=""/><br><br>
            <label>Gender: </label><select name="gender" size="1"><option value="M">Male</option><option value="F">Female</option></select> <br><br>
            <label>Age: </label><input type="text" name="age" value=""/><br><br>
            <input type="submit" name="submit" value="Register"/>  <input type="reset" name="clear" value="Reset"/>

        </fieldset>




    </form> 
    
    <?php
include 'selectRecord.php';
?>
    
</body>
</html>