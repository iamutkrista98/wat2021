<?php
//Make connection to database
include ('connection.php');
//(a)Gather from $_POST[]all the data submitted and store in variables
$fname = $_POST['fname'];
$lname = $_POST['lname'];
$email = $_POST['email'];
$password=$_POST['password'];
$gender = $_POST['gender'];
$age = $_POST['age'];



//(b)Construct INSERT query using variables holding data gathered
$query="INSERT INTO customer (FirstName, LastName, Email, Password, Gender, Age) VALUES ('$fname', '$lname', '$email', '$password', '$gender', '$age')";

//Temporarily echo $query for debugging purposes
//echo $query;

//run $query

if(mysqli_query($connection, $query)){
    echo "Record inserted successfully.";
    } else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($connection);
    }
//exit()
mysqli_close($connection);

?>