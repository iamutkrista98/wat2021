<?php
//Make connection to database
include('connection.php');
//Gather data sent from amendProducts.php page
if(isset($_POST['esubmit']))
{
$newid=$_POST['id'];
$newname=$_POST['name'];
$newprice=$_POST['price'];
$newimage=$_POST['image'];
//Produce an update query to update product record for the id provided
$sql="UPDATE products SET ProductName='$newname', ProductPrice='$newprice',ProductImageName='$newimage' WHERE ProductID='$newid'";

//run query
$qry=mysqli_query($conn,$sql); 
//Redirect to crud.php page
header( 'Location: crud.php?msg=Product Updated Successfully' ) ;
}
?>
<?php
//Make connection to database
include('connection.php');
//Gather id sent from crud.php page
$eid = $_GET['id'];
//Produce query to select the product record for the id provided
$sql = "SELECT * FROM products WHERE ProductID=$eid";
//run query and store result
$qry = mysqli_query($conn,$sql) or die(mysqli_error($conn));
//extract row from result using mysqli_fetch_assoc()and store $row
while ($row = mysqli_fetch_assoc($qry))
{
    $eid=$row['ProductID'];
    $ename=$row['ProductName'];
    $eprice=$row['ProductPrice'];
    $eimage=$row['ProductImageName'];
}
mysqli_close($conn);
?>

