<?php
//Make connection to database
include('connection.php');
if(isset($_GET['msg']))
{
    $msg = $_GET['msg'];
    echo '<h2>'.$msg.'</h2>';
}  
//create a query to select all records from products table
$sql = "SELECT * FROM products"; 
//run query and store the result in a variable called $result
$result = mysqli_query($conn,$sql);
//Use a while loop to iterate through your $result array and display 
//ProductName, ProductPrice, ProductImageName.
echo "<table border='1'>";
echo "<thead>
<tr>
<th>Product Name</th><th>Product Price</th><th>Product Image</th><th>Amend</th><th>Delete</th></tr></thead>";
echo "<tbody>";
while ($row = mysqli_fetch_array($result))
{
    echo "<tr>
    <td> ".$row['ProductName']."</td>
    <td>".$row['ProductPrice']."</td>
    <td><img src='./images/".$row['ProductImageName']."'></td>
    <td><a href=amendProduct.php?id=".$row['ProductID'].">Amend</a></td>
    
    <td><a href=deleteProduct.php?id=".$row['ProductID'].">Delete</a></td>
    
    
    </tr>
    ";

}
mysqli_close($conn);

?>