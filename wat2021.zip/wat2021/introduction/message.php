<?php
// Print some words to the screen
print "If all is well then this message will be seen when you browse
this web page";
?>