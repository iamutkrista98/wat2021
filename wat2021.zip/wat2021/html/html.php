<html>
    <head>
        <title>Recap Exercise for WAT</title>
        <link rel="stylesheet" href="main.css">
    </head>
    <body>
        <div class="Container">
            <div class="Wat">
                <div class="inner">
                    <b><span class="big">W</span>eb <span class="big">A</span>pplication <span class="big">T</span>echnology</b>
                </div>
            </div>
            <div class="links">
                <div class="inner">
                    <h1>Links</h1>
                    <ul>
                        <li><a href="">Chubkins</a></li>
                        <li><a href="">W3 Schools</a></li>
                        <li><a href="">Learn Web Dev</a></li>
                        <li><a href="">Colour References</a></li>
                    </ul>
                </div>
            </div>
            <div class="lecture">
                <div class="inner">
                    <p><b>WAT Lecture</b>
                        <span id="Lec-right"><i><br>12:00 - 13:00 LTB</i></span></p>
                        <br>
                    <div id="wed-contain"><p>Every <span id="wed">WED</span></p></div>
                </div>
            </div>
            <div class="Assesment">
                <div class="inner">
                    <h1>WAT Assessment</h1>
                    <table>
                        <tr>
                            <th>Title</th>
                            <th>Weight</th>
                            <th>Due</th>
                        </tr>
                        <tr>
                            <td>Work in progress</td>
                            <td>20%</td>
                            <td>See VLE</td>
                        </tr>
                        <tr>
                            <td>Portfolio</td>
                            <td>50%</td>
                            <td>See VLE</td>
                        </tr>
                        <tr>
                            <td>Phase Exam</td>
                            <td>30%</td>
                            <td>See VLE</td>
                        </tr>
                    </table>
                </div>
            </div>
            <div class="form">
                <div class="inner">
                    <h1>Search Property</h1>
                    <form>
                        <b>
                            <label for="Location">Location:</label>
                            <input type="text" id="Location" placeholder="e.g this or that">
                            <br><br>
                            <label for="Category">Category:</label>
                            <select id="Category">
                                <option value="Flat">Flat</option>
                                <option value="Apartment">Apartment</option>
                                <option value="House">House</option>
                            </select><br><br>
                            <label for="Bed">Beds:</label>
                            <input id="Bed" type="text" placeholder="4" size="1">
                            <br><br>
                            <input type="radio" id="Price" name="radio" value="price">
                            <label for="Price">Price</label>
                            <input type="radio" id="Beds" name="radio" value="Beds">
                            <label for="Price">Beds</label>
                            <input type="radio" id="Alpha" name="radio" value="Alpha">
                            <label for="Price">Alpha</label>
                            <br><br>
                            <input type="submit" id="submit">
                        </b>
                    </form>
                </div>
            </div>
        </div>
    </body>
</html>
